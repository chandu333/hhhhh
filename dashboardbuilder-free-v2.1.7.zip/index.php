<?php session_start();header("Lo\x63at\x69\x6f\x6e:\x20lib");exit();
?>